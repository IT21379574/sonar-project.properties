package com.example.orderapp

data class OrderModel(
    var orderId: String? = null,
    var name: String? = null,
    var details: String? = null,
    var skills: String? = null,
)
