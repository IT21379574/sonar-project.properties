package com.example.orderapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class EditOrderActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_order)
    }
}